#include<iostream>
#include<vector>
#include<cstring>
using namespace std;

int main(){

    string s("Hello World");
    cout<<s<<endl;

    string sa[10] = {"Hello","CB"};

    cout<<sa[0];
    cout<<sa[1];

    vector<string> v;
    v.push_back("Prateek");

    cout<<v[0]<<endl;


return 0;
}
