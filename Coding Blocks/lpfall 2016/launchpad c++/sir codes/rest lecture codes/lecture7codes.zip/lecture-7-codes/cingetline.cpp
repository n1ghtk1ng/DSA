#include<iostream>
using namespace std;


int main(){

    char arr[100];
    cin.getline(arr,100,'$');
    cout<<arr;

}
