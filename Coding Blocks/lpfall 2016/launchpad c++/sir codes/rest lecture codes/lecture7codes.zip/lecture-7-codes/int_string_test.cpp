#include<iostream>
using namespace std;

int main(){

int x;
cin>>x;
char a[100];
cin.get();
cin.getline(a,100);

cout<<x<<endl;
cout<<a<<endl;

return 0;
}
