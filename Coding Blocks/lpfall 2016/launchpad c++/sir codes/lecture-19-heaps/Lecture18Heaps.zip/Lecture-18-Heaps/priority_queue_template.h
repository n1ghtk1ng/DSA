#ifndef PQ_H
#define PQ_H
#include<vector>

template<typename U>
class PriorityQueue{

    vector<U> v;
    int index;

    PriorityQueue(){

    }
    void push(int key,U data){

    }



};


#endif // PQ_H
