

int kadane(int a[],int n){

    int cs=0,ms = 0;

    for(int i=0;i<n;i++){
        cs += a[i];
        if(cs<0){
            cs = 0;
        }
        ms = max(cs,ms);


    }


}
