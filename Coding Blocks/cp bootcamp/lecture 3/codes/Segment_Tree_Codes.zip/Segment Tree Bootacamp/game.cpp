#include<iostream>
using namespace std;


int game(int a[],int i,int j){
    if(i>j){
        return 0;
    }
    int option1 = a[i] + min(game(a,i+1,j-1),game(a,i+2,j));
    int option2 = a[j] + min(game(a,i+1,j-1),game(a,i,j-2));
    return max(option1,option2);
}

int main(){
    int a[] = {4,3,5,8,7,2};
    cout<<game(a,0,5)<<endl;

}
