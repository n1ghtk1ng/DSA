#include<iostream>
#include<unordered_map>
using namespace std;

int main(){
    unordered_map<string,int> m;

    m["apple"] = 100;
    m["mango"] = 80;
    m["pear"] = 60;

    string fruit;
    cin>>fruit;


    if(m.count(fruit)>0){
    cout<<"price of fruit is "<<m[fruit]<<endl;
    }
    else{
        cout<<"Fruit doesn't exist"<<endl;
    }




return 0;
}
