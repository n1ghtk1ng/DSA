#include<iostream>
#include<vector>
#include<unordered_map>
#include<map>
using namespace std;

class Graph{
    int V;

    map<string, vector<string> > adjList;
public:
    Graph(int v){
        V = v;
    }
    void addEdge(string s1,string s2){
        adjList[s1].push_back(s2);
        adjList[s2].push_back(s1);
    }
    void DFSHelper(string city,map<string,bool> &m){

        cout<< city<<" ";
        m[city] = true;

        for(auto it=adjList[city].begin();it!=adjList[city].end();it++){
            if( m[*it]==false){
                DFSHelper(*it,m);
            }
        }
    }

    void DFS(string startCity){
        map<string,bool> visited;
        for(auto it=adjList.begin();it!=adjList.end();it++){
            visited[ it->first ] = false;
        }


        DFSHelper(startCity,visited);

    }

    void print(){

        for(auto it=adjList.begin();it!=adjList.end();it++){
            cout<< it->first <<"-->";

            for(auto x = it->second.begin();x!=it->second.end();x++){
                cout<< *x <<",";
            }
            cout<<endl;

        }
    }
};


int main(){

  Graph g(4);
  g.addEdge("Kohat","Pitampura");
  g.addEdge("Kohat","Dwarka");
  g.addEdge("Rohini","Pitampura");
  g.addEdge("Dwarka","Pitampura");

  g.print();

    cout<<"DFS is "<<endl;
    g.DFS("Kohat");

return 0;
}
