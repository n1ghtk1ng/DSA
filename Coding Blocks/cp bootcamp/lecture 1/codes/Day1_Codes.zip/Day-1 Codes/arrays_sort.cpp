#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;

class Person;

bool compare(const int &a,const int &b){
    return a>b?true:false;
}


class Person{
    public:
    int money;
    char name[20];

    Person(char *n,int m){
        strcpy(name,n);
        money = m;
    }

};
bool comparePerson(const Person &a,const Person &b){
    //return a.money < b.money;
    return strcmp(a.name,b.name)<=0?true:false;
}

ostream& operator<<(ostream &os,Person &p){

    os<<"Name : "<<p.name<<endl;
    os<<"Money: "<<p.money<<endl;
    os<<endl;
    return os;
}


int main(){

    int a[] = {1,5,4,3,2};

    sort(a,a+3,compare);
    sort(a+3,a+5);

    for(int i=0;i<5;i++){
        cout<<a[i]<<" ";
    }

    Person p1("Abc",100);
    Person p2("Abaa",200);
    Person p3("Acb",150);

    vector<Person> vp;
    vp.push_back(p1);
    vp.push_back(p2);
    vp.push_back(p3);

    cout<<endl;
   // cout<<p1<<p2<<p3<<endl;

    sort(vp.begin(),vp.end(),comparePerson);

    for(int i=0;i<vp.size();i++){

        cout<< vp[i] ;
    }

}
