#include<bits/stdc++.h>
using namespace std;


class Person{
    public:
    int money;
    char name[20];

    Person(char *n,int m){
        strcpy(name,n);
        money = m;
    }

};

ostream& operator<<(ostream &os,Person &p){

    os<<"Name : "<<p.name<<endl;
    os<<"Money: "<<p.money<<endl;
    os<<endl;
    return os;
}


class myCompare{
public:
    bool operator()(Person &a,Person &b){
        return a.money < b.money;
    }
};

int main(){
    int a[] = {1,2,12,5,4,3,7};

    priority_queue<int, vector<int>, greater<int> > pq;
    for(int i=0;i<7;i++){
        pq.push(a[i]);
    }

    while(!pq.empty()){

        cout<< pq.top() <<" ";
        pq.pop();
    }

    Person p1("Abc",100);
    Person p2("Abaa",200);
    Person p3("Acb",150);

    priority_queue<Person, vector<Person>, myCompare> pp;
    pp.push(p1);
    pp.push(p2);
    pp.push(p3);

    Person p_rich = pp.top();
    cout<<"Richest person is "<< p_rich<<endl;
return 0;
}
