#include<bits/stdc++.h>
using namespace std;


int main(){
 set<int> s;
 int arr[] = {4,5,1,2,9,10,8,3,3,2};
 for(int i = 0;i<10;i++)
    s.insert(arr[i]);
 for(set<int>::iterator it = s.begin();it != s.end();it++)
    cout<<*it<<endl;

 s.erase(9);
 auto it = s.find(9);
 if(it==s.end()){
    cout<<"Not found";
 }
 else{
   // cout<<(it-s.begin()) <<endl;
 }

}
