#include<bits/stdc++.h>
using namespace std;

int main(){
    int arr[] = {1,2,3,4,4,4,4,5,6,7};
vector<int> v(arr,arr+10);

    vector<int>::iterator iv;
    for(iv = v.begin();iv!=v.end();iv++){

        cout<< *iv <<endl;
    }


bool is_present = binary_search(v.begin(),v.end(),6);
vector<int>::iterator it = find(v.begin(),v.end(),4);
cout<<"Index "<< it - v.begin() <<endl;
cout<<"Value "<<*it <<endl;

auto  firstOcc = lower_bound(v.begin(),v.end(),4);
auto lastOcc = upper_bound(v.begin(),v.end(),4);
//cout<<in<<endl;

cout<<"Index of first Occ "<< firstOcc - v.begin()<<endl;
cout<<"index of last occ "<<  lastOcc - v.begin() - 1 <<endl;

return 0;
}
