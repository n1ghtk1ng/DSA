#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
using namespace std;

int main(){

    vector<int> v;
    for(int i=1;i<10;i++){
        v.push_back(i);
    }

    v.pop_back();
    v.pop_back();

    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    /*
    string s("hello world");
    cout<<s<<endl;

    char sa[100];
    //cin>>sa ;
    cin.getline(sa,100);
    cout<<sa<<endl;

    string s1;
    getline(cin,s1);

    cout<<s1
    */

    string s[10] = {"apple","mango","guava"};
    for(int i=3;i<6;i++){
        getline(cin,s[i]);
    }
    vector<string> vs;

    for(int i=0;i<6;i++){
        //cout<<s[i]<<endl;
        vs.push_back(s[i]);
    }

    sort(vs.begin(), vs.end());

    for( int i=0;i<vs.size();i++){
        cout<< vs[i] <<" ";
    }
    int a[] = {1,2,3,4,5};
    vector<int> vi(a,a+5);

    for(int i=0;i<vi.size();i++){
        cout<<vi[i]<<endl;
    }






return 0;
}
